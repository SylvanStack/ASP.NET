﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        private SE[] se ={ new SE(111, "王小毛", 26),
                           new SE(112, "周新雨", 22),
                           new SE(113, "张烨", 30)};
        public Form1()
        {
            InitializeComponent();
        }

        public void UpdateView()
        {
            listView1.Items.Clear();
            for (int i = 0; i < se.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                item.Text = se[i].ID.ToString();
                item.SubItems.Add(se[i].Name);
                item.SubItems.Add(se[i].Age.ToString());
                item.SubItems.Add(se[i].Evaluation);
                item.SubItems.Add(se[i].Score.ToString());
                listView1.Items.Add(item);
            }
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateView();
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmJudge frm = new FrmJudge();
            frm.getse += new GetSE(GetSE);
            frm.setse += new SetSE(SetSE);
            frm.Show();
        }
        public SE GetSE()
        {
            SE se1 = new SE();
            se1.Name = listView1.SelectedItems[0].SubItems[1].Text;
            se1.Evaluation = listView1.SelectedItems[0].SubItems[3].Text;
            se1.Score = Convert.ToInt32(listView1.SelectedItems[0].SubItems[4].Text);
            return se1;
        }
        public void SetSE(SE se)
        {
            listView1.SelectedItems[0].SubItems[3].Text = se.Evaluation;
            listView1.SelectedItems[0].SubItems[4].Text = Convert.ToString(se.Score);
        }
    }
}
