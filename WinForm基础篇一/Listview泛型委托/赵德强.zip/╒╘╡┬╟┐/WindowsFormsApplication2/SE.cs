﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    public class SE
    {
        private int id;
        private string name;
        private int age;
        private string evaluation;
        private int score;

        public SE(int id, string name, int age)
        {
            this.id = id;
            this.name = name;
            this.age = age;
            this.evaluation = "未评价";
            this.score = 0;
        }

        public SE() { }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string Evaluation
        {
            get { return evaluation; }
            set { evaluation = value; }
        }
        public int Score
        {
            get { return score; }
            set
            {
                if (value < 100 && value > 0)
                {
                    score = value;
                }
            }
        }
    }
}
