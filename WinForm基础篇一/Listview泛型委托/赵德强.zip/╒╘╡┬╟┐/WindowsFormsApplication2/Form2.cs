﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public delegate SE GetSE();
    public delegate void SetSE(SE se);
    public partial class FrmJudge : Form
    {
        public event GetSE getse;
        public event SetSE setse;
        public FrmJudge()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SE se = new SE();
            try
            {
                se.Evaluation = richTextBox1.Text.Trim();
                se.Score = Convert.ToInt32(textBox2.Text.Trim());
            }
            catch 
            {
                MessageBox.Show("输入错误");
            }
            setse(se);
            this.Close();
        }

        private void FrmJudge_Load(object sender, EventArgs e)
        {
            textBox1.Text = getse().Name;
            richTextBox1.Text = getse().Evaluation;
            textBox2.Text = Convert.ToString(getse().Score);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
